package com.natixis.academy.api.config;

import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.OAuthFlow;
import io.swagger.v3.oas.annotations.security.OAuthFlows;
import io.swagger.v3.oas.annotations.security.OAuthScope;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.servers.Server;
import io.swagger.v3.oas.models.tags.Tag;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;

@Configuration
@SecurityScheme(
        type = SecuritySchemeType.OAUTH2,
        name = "ClientCredentials",
        flows = @OAuthFlows(
                clientCredentials = @OAuthFlow(
                        tokenUrl = "/token",
                        scopes = {@OAuthScope(name = "read")}
                )
        )
)
public class SwaggerConfig {

    @Value("${version}")
    private String projectVersion;

    @Value("${server.url}")
    private String serverUrl;

    @Bean
    public OpenAPI api() {
        return new OpenAPI()
                .info(new Info()
                        .title("Football API")
                        .description("Java Academy API.")
                        .version(projectVersion)
                        .contact(new Contact().name("Nelson Costa")
                                .url("https://confluence-mut.d.bbg/display/SEP/SEP+-+Sepia+Home")
                                .email("nelson.costa@natixis.com")
                        )
                )
                .servers(Collections.singletonList(new Server().url(serverUrl)))
                .addSecurityItem(new SecurityRequirement().addList("ClientCredentials", "read"))
                .addTagsItem(new Tag().name("Football"));
    }
}
