package com.natixis.academy.api.config.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.filter.GenericFilterBean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Nathan Lion
 */
public class AuthenticationFilter extends GenericFilterBean {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String token = httpRequest.getHeader("X-Authorization");
        if (token == null)
            token = httpRequest.getParameter("access_token");

        if (token == null)
            token = httpRequest.getHeader("Authorization");

        try {
            if (token == null)
                throw new AccessDeniedException("No token found in headers");
            // Cut the bearer part
            token = (token.startsWith("Bearer ")) ? token.replaceFirst("Bearer ", "") : token;

            // Decoding the token with the secret key
            Jws<Claims> claims = TokenVerifier.getClaims(token);
            String applicationGroupId = claims.getBody().get("appname").toString().split("_")[0];

            List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
            authorities.add(new SimpleGrantedAuthority("read"));
            UserDetails p = new User(applicationGroupId, "none", authorities);
            Authentication authentication = new AnonymousAuthenticationToken("key", p, authorities);
            SecurityContextHolder.getContext().setAuthentication(authentication);

            chain.doFilter(request, response);
        } catch (Exception badJwt) {
            SecurityContextHolder.clearContext();
            logger.error("Token error : " + badJwt.getLocalizedMessage(), badJwt);
            httpResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED, badJwt.getLocalizedMessage());
        }

    }
}
