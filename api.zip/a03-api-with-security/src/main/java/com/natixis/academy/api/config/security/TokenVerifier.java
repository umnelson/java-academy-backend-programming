package com.natixis.academy.api.config.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.io.ClassPathResource;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

public class TokenVerifier {

    private TokenVerifier() {
        throw new IllegalStateException("TokenVerifier class");
    }


    protected static final Log logger = LogFactory.getLog(TokenVerifier.class);

    /**
     * @param aToken The token to parse
     * @return The claims for the token
     * @throws Exception             Generic exception
     * @throws FileNotFoundException file not found exception
     * @throws CertificateException  certificate exception
     */
    public static Jws<Claims> getClaims(String aToken)
            throws Exception {

        Jws<Claims> lJws;
        JwtParser lParser;

        try (InputStream lResource = new ClassPathResource("api.jwt.cer").getInputStream()) {
            CertificateFactory f = CertificateFactory.getInstance("X.509");
            X509Certificate certificate = (X509Certificate) f.generateCertificate(lResource);
            lParser = Jwts.parser()
                    .verifyWith(certificate.getPublicKey())
                    .clockSkewSeconds(0L)
                    .build();

            lJws = lParser.parseSignedClaims(aToken);
            return lJws;
        }
    }

}
