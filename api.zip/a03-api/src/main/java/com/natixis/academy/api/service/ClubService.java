package com.natixis.academy.api.service;

import com.natixis.academy.api.dao.ClubDao;
import com.natixis.academy.api.dao.ClubSearchDao;
import com.natixis.academy.api.dao.criteria.ClubCriteria;
import com.natixis.academy.api.domain.Club;
import com.natixis.academy.api.service.rule.ClubRule;
import com.natixis.academy.api.service.rule.ClubRuleChecker;
import com.natixis.sepia.service.rule.exception.BusinessRuleListException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class ClubService {

    // ============= RESOURCES ===============

    private final ClubSearchDao clubSearchDao;
    private final ClubDao clubCrudDao;
    private final ClubRuleChecker clubRuleChecker;

    // ============= METHODS ===============

    public List<Club> search(ClubCriteria criteria) {
        return this.clubSearchDao.search(criteria);
    }

    public Long count(ClubCriteria criteria) {
        return this.clubSearchDao.count(criteria);
    }

    public Club create(Club club) throws BusinessRuleListException {
        // 1. Check business rules
        this.clubRuleChecker.controlRules(club, ClubRule.values());

        // 2. persist
        return this.clubCrudDao.save(club);
    }
}
