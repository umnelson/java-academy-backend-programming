package com.natixis.academy.api.config.modelmapper;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@RequiredArgsConstructor
@Component
public class ConvertersConfiguration {

    private final ModelMapper mapper;
    private final List<Converter<?, ?>> converters;


    @PostConstruct
    private void addConvertersToModelMapper() {

        for (Converter<?, ?> converter : converters) {
            mapper.addConverter(converter);
        }
    }
}
