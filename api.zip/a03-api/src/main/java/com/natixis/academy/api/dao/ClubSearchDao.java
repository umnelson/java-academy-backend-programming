package com.natixis.academy.api.dao;

import com.natixis.academy.api.dao.criteria.ClubCriteria;
import com.natixis.academy.api.dao.fetching.ClubFetching;
import com.natixis.academy.api.domain.Club;
import com.natixis.sepia.dao.search.SearchContext;
import com.natixis.sepia.dao.search.SearchDao;
import jakarta.persistence.EntityGraph;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ClubSearchDao extends SearchDao<Club, ClubCriteria, ClubFetching> {
    protected ClubSearchDao() {
        super(Club.class);
    }

    @Override
    protected void filter(SearchContext<ClubCriteria, ClubFetching> searchContext) {
        ClubCriteria criteria = searchContext.getCriteria();

        if (CollectionUtils.isNotEmpty(criteria.getIds())) {
            searchContext.addCondition("club.id in :ids");
            searchContext.addParameter("ids", criteria.getIds());
        }

        searchContext.addStringCondition("club.name", "name", criteria.getName());

        if (criteria.getCountry() != null) {
            searchContext.addCondition("club.country in :country");
            searchContext.addParameter("country", criteria.getCountry());
        }

    }

    @Override
    protected void fetch(EntityGraph<Club> entityGraph, SearchContext<ClubCriteria, ClubFetching> searchContext) {
        ClubFetching fetching = searchContext.getCriteria().getFetching();

        if (BooleanUtils.isTrue(fetching.getStadium())) {
            entityGraph.addAttributeNodes("stadium");
        }
    }

    @Override
    protected void fetchSublists(List<Club> list, SearchContext<ClubCriteria, ClubFetching> searchContext) {

    }
}
