package com.natixis.academy.api.dto.error;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Schema(description = "further information for httpStatus 404")
public class GenericError {
    @Schema(requiredMode = Schema.RequiredMode.REQUIRED, description = "HTTP Error Code")
    private int code;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED, description = "Error list, contains at least one item")
    private List<ErrorItem> errors = new ArrayList<>();

    public void addError(ErrorItem error) {
        this.errors.add(error);
    }
}
