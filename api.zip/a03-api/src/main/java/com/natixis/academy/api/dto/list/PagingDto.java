package com.natixis.academy.api.dto.list;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Getter
@Setter
@Schema(name = "Paging")
public class PagingDto {

    // ========== ATTRIBUTES ==========

    /**
     * Value to set on pageNumber to get the first page
     */
    public static final Integer FIRST_PAGE = 1;

    @Schema(description = "The page size (the number of elements returned on a call).", requiredMode = Schema.RequiredMode.REQUIRED)
    private Integer pageSize;

    @Schema(description = "The index of the requested page (starts at 1).", requiredMode = Schema.RequiredMode.REQUIRED)
    private Integer pageNumber;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    private Long totalElements;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    private Long totalPages;


    // ========== CONSTRUCTORS ==========

    public PagingDto() {
    }

    public PagingDto(Integer pageNumber, Integer pageSize) {
        setPageSize(pageSize);
        setPageNumber(pageNumber);
    }

    public PagingDto(Integer pageNumber, Integer pageSize, Long totalElements) {
        setTotalElements(totalElements);
        setPageSize(pageSize);
        setPageNumber(pageNumber);
    }

    // ========== extends Object ==========

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PagingDto that = (PagingDto) o;
        return Objects.equals(pageSize, that.pageSize)
                && Objects.equals(pageNumber, that.pageNumber)
                && Objects.equals(totalElements, that.totalElements)
                && Objects.equals(totalPages, that.totalPages);
    }

    @Override
    public int hashCode() {
        return Objects.hash(pageSize, pageNumber, totalElements, totalPages);
    }

    // ========== METHODS ==========

    /**
     * Returns the "firstResult" parameter expected by JPA in the Queries
     */
    @JsonIgnore
    public Integer getFirstResult() {
        return (pageNumber - 1) * pageSize;
    }

    private void calculateTotalPages() {
        if (pageSize != null && pageNumber != null && totalElements != null) {
            this.totalPages = (totalElements / pageSize) + 1;
        }
    }


    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
        calculateTotalPages();
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
        calculateTotalPages();
    }

    public void setTotalElements(Long totalElements) {
        this.totalElements = totalElements;
        calculateTotalPages();
    }
}
