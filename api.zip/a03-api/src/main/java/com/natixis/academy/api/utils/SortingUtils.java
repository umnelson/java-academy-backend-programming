package com.natixis.academy.api.utils;

import com.natixis.sepia.dao.search.criteria.Sorting;
import com.natixis.sepia.dao.search.criteria.SortingDirectionEnum;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

public class SortingUtils {

    private SortingUtils() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * converts the sorting string in a List of Sorting objects
     *
     * @param sort the string containing the properties and directions to sort by. Example: 'code,desc|label,asc'
     * @return order by list
     */
    public static List<Sorting> getOrderBy(String sort) {

        if (StringUtils.isNotBlank(sort)) {
            return Arrays.stream(sort.split("\\|"))
                    .map(String::trim)
                    .map(entry -> {
                        String[] attributes = entry.split(",");
                        String property = attributes[0].trim();
                        String direction = attributes[1].trim();
                        return new Sorting(property, SortingDirectionEnum.valueOf(direction.toUpperCase()));
                    })
                    .toList();
        }

        return new ArrayList<>();
    }


    /**
     * converts the sorting string in a List of Sorting objects
     *
     * @param sort the string containing the properties and directions to sort by. Example: 'code,desc|label,asc'
     */
    public static List<Sorting> getOrderBy(String sort, Map<String, String> propertyMap) {

        if (StringUtils.isNotBlank(sort)) {
            return Arrays.stream(sort.split("\\|"))
                    .map(String::trim)
                    .map(entry -> {
                        String[] attributes = entry.split(",");
                        String property = attributes[0];
                        String direction = attributes[1];
                        return new Sorting(propertyMap.containsKey(attributes[0]) ? propertyMap.get(property) : property, SortingDirectionEnum.valueOf(direction.toUpperCase()));
                    })
                    .toList();
        }

        return new ArrayList<>();
    }

    /**
     * Checks if sort properties are valid
     *
     * @param toCheckList properties to check
     * @param validList list of valid properties
     * @return true if all properties are valid properties, false otherwise
     */
    public static boolean areSortablePropertiesValid(List<Sorting> toCheckList, List<String> validList) {
        if (CollectionUtils.isNotEmpty(toCheckList)) {

            List<String> propertiesToCheck = toCheckList.stream()
                    .map(Sorting::getProperty)
                    .collect(Collectors.toList());

            return new HashSet<>(validList).containsAll(propertiesToCheck);
        }
        return true;
    }
}
