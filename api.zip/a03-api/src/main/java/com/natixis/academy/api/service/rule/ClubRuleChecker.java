package com.natixis.academy.api.service.rule;

import com.natixis.academy.api.dao.ClubSearchDao;
import com.natixis.academy.api.dao.criteria.ClubCriteria;
import com.natixis.academy.api.domain.Club;
import com.natixis.sepia.service.rule.BusinessRuleChecker;
import com.natixis.sepia.service.rule.BusinessRuleCheckerContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
public class ClubRuleChecker implements BusinessRuleChecker<Club> {

    // ============= RESOURCES ===============

    private final ClubSearchDao clubSearchDao;

    // ============= METHOD ===============

    @Override
    public void checkRules(Club club, BusinessRuleCheckerContext context) {
        if (context.mustControlRule(ClubRule.RULE_001)) {
            if (this.clubSearchDao.exists(
                    new ClubCriteria()
                            .exactName(club.getName())
                            .country(club.getCountry()))
            ) {
                context.addError(ClubRule.RULE_001, club.getName(), club.getCountry().getCode());
            }
        }
    }

}
