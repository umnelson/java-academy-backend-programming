package com.natixis.academy.api.controller;

import com.natixis.academy.api.dao.criteria.ClubCriteria;
import com.natixis.academy.api.dao.fetching.ClubFetching;
import com.natixis.academy.api.domain.Club;
import com.natixis.academy.api.dto.ClubCreateRequestDto;
import com.natixis.academy.api.dto.ClubDto;
import com.natixis.academy.api.dto.ClubsDto;
import com.natixis.academy.api.dto.error.GenericError;
import com.natixis.academy.api.dto.list.PagingDto;
import com.natixis.academy.api.service.ClubService;
import com.natixis.sepia.service.rule.exception.BusinessRuleListException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@CrossOrigin
@RequestMapping("/football/v1/clubs")
@Tag(name = "Football")
public class ClubController {

    // ============= RESOURCES ===============

    private final ClubService clubService;
    private final ModelMapper mapper;

    // ============= METHODS ===============

    @Operation(summary = "Get some clubs", description = "Returns a list containing some clubs")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Clubs found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ClubsDto.class))),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericError.class))),
            @ApiResponse(responseCode = "500", description = "Unexpected server error")})
    @GetMapping
    public ResponseEntity<ClubsDto> getClubs(
            @Parameter(description = "Filters clubs by name (partial).") @RequestParam(required = false) String name,
            @Parameter(description = "Filters clubs by countryCode.") @RequestParam(required = false) String countryCode,
            @Parameter(description = "Sorting information. Example 'sort=name,desc|countryCode,asc'. Properties that can be used: name, countryCode. If a http client is being used to call this endpoint, please encode the character | (replace | by %7C).") @RequestParam(required = false) String sort,
            @Parameter(description = "Page size information.") @RequestParam(required = false, defaultValue = "10") Integer pageSize,
            @Parameter(description = "Page number to be returned.") @RequestParam(required = false, defaultValue = "1") Integer pageNumber,
            @Parameter(description = "Indicates if it is to be returned the total number of elements.") @RequestParam(required = false, defaultValue = "false") boolean counts
    ) {

        ClubCriteria criteria = new ClubCriteria()
                .partialName(name)
                .country(countryCode)
                .paging(pageNumber, pageSize)
                .sorting(sort)
                .fetching(new ClubFetching().stadium(true));

        List<ClubDto> clubs = this.clubService.search(criteria)
                .stream()
                .map(vInterestRate -> mapper.map(vInterestRate, ClubDto.class))
                .toList();

        PagingDto paging = new PagingDto(pageNumber, pageSize, counts ? this.clubService.count(criteria) : null);

        return ResponseEntity.ok(new ClubsDto(clubs, paging));
    }

    @Operation(summary = "Create a club", description = "Returns a list containing some clubs")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Club created", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ClubDto.class))),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericError.class))),
            @ApiResponse(responseCode = "500", description = "Unexpected server error")})
    @PostMapping
    public ResponseEntity<ClubDto> createClub(@RequestBody ClubCreateRequestDto createRequest
    ) throws BusinessRuleListException {
        Club club = this.mapper.map(createRequest, Club.class);
        return ResponseEntity.ok(this.mapper.map(this.clubService.create(club), ClubDto.class));
    }
}
