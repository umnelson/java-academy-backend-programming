package com.natixis.academy.api.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import io.swagger.v3.oas.models.tags.Tag;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;

@Configuration
public class SwaggerConfig {

    @Value("${version}")
    private String projectVersion;

    @Value("${server.url}")
    private String serverUrl;

    @Bean
    public OpenAPI api() {
        return new OpenAPI()
                .info(new Info()
                        .title("Football API")
                        .description("Java Academy API.")
                        .version(projectVersion)
                        .contact(new Contact().name("Nelson Costa")
                                .url("https://confluence-mut.d.bbg/display/SEP/SEP+-+Sepia+Home")
                                .email("nelson.costa@natixis.com")
                        )
                )
                .servers(Collections.singletonList(new Server().url(serverUrl)))
                .addTagsItem(new Tag().name("Football"));
    }
}
