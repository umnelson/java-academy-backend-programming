package com.natixis.academy.api.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Getter
@Setter
@Schema(name = "Club")
public class ClubDto extends ClubCreateRequestDto {

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    private Integer id;

    // ========== Object ==========

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ClubDto clubDto)) return false;
        if (!super.equals(o)) return false;
        return Objects.equals(getId(), clubDto.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getId());
    }

    @Override
    public String toString() {
        return super.toString();
    }

}
