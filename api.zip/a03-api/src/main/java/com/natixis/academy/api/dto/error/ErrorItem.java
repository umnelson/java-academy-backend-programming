package com.natixis.academy.api.dto.error;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ErrorItem {

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED, description = "Error code")
    private String code;
    @Schema(requiredMode = Schema.RequiredMode.REQUIRED, description = "English error message")
    private String messageEn;
    @Schema(requiredMode = Schema.RequiredMode.REQUIRED, description = "French error message")
    private String messageFr;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ErrorItem errorItem)) return false;
        return Objects.equals(getCode(), errorItem.getCode()) && Objects.equals(getMessageEn(), errorItem.getMessageEn()) && Objects.equals(getMessageFr(), errorItem.getMessageFr());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCode(), getMessageEn(), getMessageFr());
    }
}
