package com.natixis.academy.api.dao.fetching;

import com.natixis.sepia.dao.search.criteria.IFetching;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ClubFetching implements IFetching {

    private Boolean stadium;

    // ============= FLUENT SETTERS ===============

    public ClubFetching stadium(Boolean stadium) {
        this.stadium = stadium;
        return this;
    }
}
