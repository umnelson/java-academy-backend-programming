package com.natixis.academy.api.config;

import com.natixis.academy.api.dao.CountryDao;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@EnableScheduling
public class CacheLoader {

    // ========== RESOURCES ==========
    private final CountryDao countryDao;

    // ========== METHODS ==========

    /**
     * Loads all cacheable entities
     */
    public void loadCache() {
        // Caching entities (JPA)
        this.countryDao.findAll();
    }

    /**
     * Reload the cache day by day
     */
    @Scheduled(fixedRate = 86400000)
    public void reloadCache() {
        // clear 3rd level of cache
        //cacheManager.getCacheNames()
        //        .forEach(cacheName -> Objects.requireNonNull(cacheManager.getCache(cacheName)).clear());
        // clear 2nd level of cache
        //this.entityManager.getEntityManagerFactory().getCache().evictAll();

        this.loadCache();
    }

}
