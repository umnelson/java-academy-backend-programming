package com.natixis.academy.api.domain;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.List;
import java.util.Objects;

@Getter
@Setter
@Entity
@Table(name = "CLUB")
public class Club {

    @Id
    @Column(name = "ID")
    @GeneratedValue
    private Integer id;

    @Column(name = "NAME")
    private String name;

    @ManyToOne
    @JoinColumn(name = "FK_COUNTRY")
    private Country country;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "FK_STADIUM")
    private Stadium stadium;

    @OneToMany(mappedBy = "club")
    @JsonManagedReference
    private List<Player> players;

    @OneToMany(mappedBy = "clubHome")
    @JsonManagedReference
    private List<Match> matchesHome;

    @OneToMany(mappedBy = "clubAway")
    @JsonManagedReference
    private List<Match> matchesAway;


    // ========== CONSTRUCTORS ==========

    public Club() {
    }

    public Club(Integer id) {
        this.id = id;
    }

    public Club(String name, Country country, Stadium stadium) {
        this.name = name;
        this.country = country;
        this.stadium = stadium;
    }

    // ========== Object ==========


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Club club = (Club) o;
        return Objects.equals(id, club.id) && Objects.equals(country, club.country);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        ToStringBuilder builder = new ToStringBuilder(this, ToStringStyle.SIMPLE_STYLE);
        builder.append("name", name);
        builder.append("country", country);
        builder.append("stadium", stadium);
        return builder.toString();
    }

}
