package com.natixis.academy.api.service.rule;

import com.natixis.sepia.service.rule.BusinessRule;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum ClubRule implements BusinessRule {
    // we can not have more then one club with the same name within the same country
    RULE_001("BR-CLUB-001");

    private final String code;
}
