package com.natixis.academy.api.config;

import com.natixis.academy.api.dto.error.ErrorItem;
import com.natixis.academy.api.dto.error.GenericError;
import com.natixis.sepia.service.rule.exception.BusinessRuleException;
import com.natixis.sepia.service.rule.exception.BusinessRuleListException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.Locale;


/**
 * API Exception Handler
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
@RestController
public class RestApiExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Locale LOCALE_EN = Locale.ENGLISH;
    private static final Locale LOCALE_FR = Locale.FRENCH;


    /**
     * Handle BusinessRuleListException on API Call
     *
     * @param ex - BusinessRuleListException
     * @return an GenericError
     */
    @ExceptionHandler(BusinessRuleListException.class)
    public final ResponseEntity<Object> handleBusinessRuleException(BusinessRuleListException ex) {
        return buildResponseEntityWithBusinessRuleErrors(ex);
    }

    /**
     * Format Response Message
     *
     * @param ex * @param apiError * @return
     */
    public ResponseEntity<Object> buildResponseEntityWithBusinessRuleErrors(BusinessRuleListException ex) {
        GenericError apiError = new GenericError();
        apiError.setCode(HttpStatus.BAD_REQUEST.value());
        for (BusinessRuleException businessRuleException : ex.getBusinessRuleExceptions()) {
            // getting error messages from resource bundle formatted with parameters
            String errorMessageEn = this.getMessageSource().getMessage(businessRuleException.getRule().getCode(), businessRuleException.getMessageParams(), LOCALE_EN);
            String errorMessageFr = this.getMessageSource().getMessage(businessRuleException.getRule().getCode(), businessRuleException.getMessageParams(), LOCALE_FR);

            apiError.addError(new ErrorItem(businessRuleException.getRule().getCode(), errorMessageEn, errorMessageFr));

        }
        return new ResponseEntity<>(apiError, HttpStatus.BAD_REQUEST);
    }
}
