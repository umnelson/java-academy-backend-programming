package com.natixis.academy.api.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Objects;

@Getter
@Setter
@Schema(name = "ClubCreateRequest")
public class ClubCreateRequestDto {

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    private String name;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    private CountryDto country;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    private StadiumDto stadium;

    // ========== Object ==========

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ClubCreateRequestDto that)) return false;
        return Objects.equals(getName(), that.getName()) && Objects.equals(getCountry(), that.getCountry()) && Objects.equals(getStadium(), that.getStadium());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName(), getCountry(), getStadium());
    }

    @Override
    public String toString() {
        ToStringBuilder builder = new ToStringBuilder(this, ToStringStyle.SIMPLE_STYLE);
        builder.append("name", name);
        builder.append("country", country);
        builder.append("stadium", stadium);
        return builder.toString();
    }

}
