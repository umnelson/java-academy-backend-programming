package com.natixis.academy.api.domain;

import jakarta.persistence.*;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Objects;

@Entity
@Table(name="COUNTRY")
@Cacheable
public class Country {

	@Id
	@Column(name="CODE", length=3)
	private String code;
	
	@Column(name="NAME", length=50)
	private String name;


	// ========== FLUENT SETTERS ==========

	public Country code(String code) {
		this.code = code;
		return this;
	}
	
	// ========== CONSTRUCTORS ==========
	
	public Country() {
	}
	
	public Country(String code, String name) {
		this.code = code;
		this.name = name;
	}
	
	// ========== Object ==========

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Country country)) return false;
		return Objects.equals(getCode(), country.getCode());
	}

	@Override
	public int hashCode() {
		return Objects.hash(code);
	}

	@Override
	public String toString() {
		ToStringBuilder builder = new ToStringBuilder(this, ToStringStyle.SIMPLE_STYLE);
		builder.append("code", code);
		builder.append("name", name);
		return builder.toString();
	}	
	
	// ========== GETTERS & SETTERS ==========
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
}
