package com.natixis.academy.api.dao.criteria;

import com.natixis.academy.api.dao.fetching.ClubFetching;
import com.natixis.academy.api.domain.Country;
import com.natixis.academy.api.utils.SortingUtils;
import com.natixis.sepia.dao.search.criteria.GenericCriteria;
import com.natixis.sepia.dao.search.criteria.Paging;
import com.natixis.sepia.dao.search.domain.StringSearch;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
public class ClubCriteria extends GenericCriteria<ClubFetching> {

    public static final Map<String, String> sortableProperties = Map.of(
            "name", "name",
            "countryCode", "country.code"
    );

    private List<Integer> ids;
    private StringSearch name;
    private Country country;

    // ============= FLUENT SETTERS ===============

    public ClubCriteria ids(Integer... ids) {
        this.ids = Arrays.asList(ids);
        return this;
    }

    public ClubCriteria exactName(String exactName) {
        if (exactName != null) {
            this.name = new StringSearch().exactMatches(exactName);
        }

        return this;
    }

    public ClubCriteria partialName(String partialName) {
        if (partialName != null) {
            this.name = new StringSearch().like(partialName);
        }

        return this;
    }

    public ClubCriteria country(String countryCode) {
        if (countryCode != null) {
            this.country = new Country().code(countryCode);
        }

        return this;
    }

    public ClubCriteria country(Country country) {
        this.country = country;
        return this;
    }

    public ClubCriteria fetching(ClubFetching fetching) {
        super.setFetching(fetching);
        return this;
    }

    public ClubCriteria paging(Integer pageNumber, Integer pageSize) {
        super.setPaging(new Paging((pageNumber - 1) * pageSize, pageSize));
        return this;
    }

    public ClubCriteria sorting(String sortString) {
        super.orderBy(SortingUtils.getOrderBy(sortString, sortableProperties));
        return this;
    }

    // ============= OBJECT ===============

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ClubCriteria that)) return false;
        if (!super.equals(o)) return false;
        return Objects.equals(getIds(), that.getIds()) && Objects.equals(getName(), that.getName()) && Objects.equals(getCountry(), that.getCountry());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getIds(), getName(), getCountry());
    }
}
