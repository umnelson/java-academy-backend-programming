package com.natixis.academy.api.dto;

import com.natixis.academy.api.dto.list.PagingDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.Objects;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Schema(name = "Clubs")
public class ClubsDto {

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    private List<ClubDto> items;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    private PagingDto page;

    // ========== Object ==========

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ClubsDto that)) return false;
        return Objects.equals(items, that.items) && Objects.equals(page, that.page);
    }

    @Override
    public int hashCode() {
        return Objects.hash(items, page);
    }
}
