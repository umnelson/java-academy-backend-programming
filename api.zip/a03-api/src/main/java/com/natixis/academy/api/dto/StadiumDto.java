package com.natixis.academy.api.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Objects;

@Getter
@Setter
@Schema(name = "Stadium")
public class StadiumDto {

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    private String name;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    private Integer capacity;

    // ========== Object ==========

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StadiumDto that)) return false;
        return Objects.equals(getName(), that.getName()) && Objects.equals(getCapacity(), that.getCapacity());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName(), getCapacity());
    }

    @Override
    public String toString() {
        ToStringBuilder builder = new ToStringBuilder(this, ToStringStyle.SIMPLE_STYLE);
        builder.append("name", name);
        builder.append("capacity", capacity);
        return builder.toString();
    }

}
