package com.natixis.academy.api.service;

import com.natixis.academy.api.dao.CountryDao;
import com.natixis.academy.api.domain.Country;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class CountryService {

    private final CountryDao countryDao;

    public List<Country> findAll() {
        return this.countryDao.findAll();
    }
}
