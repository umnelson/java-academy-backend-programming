package com.natixis.academy.api;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@ComponentScan(basePackages = {"com.natixis.sepia", "com.natixis.academy"})
@EnableCaching
@EnableScheduling
public class ApiSpringApplication extends SpringBootServletInitializer {


    /**
     * Allows to run a SpringApplication from a traditional WAR archive deployed on a web container
     *
     * @param application
     * @return
     */
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(ApiSpringApplication.class);
    }

    public static void main(String[] args) {
        org.springframework.boot.SpringApplication.run(ApiSpringApplication.class, args);
    }

}
